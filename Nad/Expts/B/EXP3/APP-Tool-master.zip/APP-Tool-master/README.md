APP-Tool
========

Automated Post Processing (APP) Tool is a ns2 tracefile Analyser.  

The application requires a Linux based environment and following libraries:

	Gtk+ for python: python-gi
	
	MatplotLib Library: python-matplotlib

To run:

	click GUI_Main.py
	
	or
	
	in terminal : python GUI_Main.py
	
	
Copyright (c) 2014 NITK WiNG - Sayan Paul, Jay Priyadarshi, Sasank Channapradaga, Spriha Awinpushpam, Mohit P. Tahiliani

