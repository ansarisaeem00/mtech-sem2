apt-get update
apt-get  install -y ns2 nam

