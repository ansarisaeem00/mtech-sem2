# NAD SIMULATOR
Ex1-Simulate a 3 node point to point network with duplex links
between them. Set the Queue size and vary the bandwidth and find
the number of packets dropped. 

Ex2-Simulate a four-node point-to-point network, and connect the links
as follows: n0->n2, n1->n2 and n2->n3. Apply TCP agent changing
the parameters and determine the number of packets sent/received by
TCP/UDP.

Ex3-Simulate the different types of internet traffic such as FTP and
TELNET over network and analyze the throughput
